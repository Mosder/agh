from data import runtests

def my_solve(N, M, holes, pieces):
    print(f"Plansza {N} x {M}, dziur: {len(holes)}, figur: {len(pieces)}")
    for i, j in holes:
        pass
    for kind, i, j in pieces:
        pass
    return False

runtests(my_solve)
