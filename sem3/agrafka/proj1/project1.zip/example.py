from data import runtests

def my_solve(N, streets, lords):
    print(f"Place: {N}, ulice: {len(streets)}, lordowie: {len(lords)}")
    for a, b, t in streets:
        pass
    return 42

runtests(my_solve)
